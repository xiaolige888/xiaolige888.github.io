Authors
=======

 * Ben Firshman

Thanks to:

 * Jamie Sanders for vNES, the Java emulator that JSNES owes so much to.
 * Matt Westcott for JSSpeccy, the original inspiration for JSNES.
 * Connor Dunn for a patch that dramatically increased performance on Chrome.
 * Jens Lindstrom for some optimisations.
 * Rafal Chlodnicki for an Opera fix.
 * Ecin Krispie for fixing player 2 controls.
